package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import com.example.domain.*
import com.fasterxml.jackson.databind.JsonNode
import java.time.Instant
import java.util.UUID
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.edit

@Entity(tableName = "events")
data class Event(@PrimaryKey val id: String, val createdAt: String, val kind: String, val payload: String)
@Entity(tableName = "observations", foreignKeys = [ForeignKey(entity = Event::class,parentColumns = ["id"],childColumns = ["eventId"],onDelete = ForeignKey.CASCADE)], indices = [Index("eventId")])
data class Observation(@PrimaryKey val id: String, val eventId: String, val observedAt: String, val payload: String)
@Entity(tableName = "tasks")
data class Task(@PrimaryKey val id: String, val title: String, val note: String, val checklist: String, val createdAt: String)
@Entity(tableName = "attachments", foreignKeys = [ForeignKey(entity = Task::class,parentColumns = ["id"],childColumns = ["taskId"],onDelete = ForeignKey.CASCADE)], indices = [Index("taskId")])
data class Attachment(@PrimaryKey val id: String, val taskId: String?, val digest: String, val mime: String, val size: String, val provenance: String, val createdAt: String)
@Dao interface RecordsDao {
    @Query("SELECT * FROM events ORDER BY createdAt DESC") fun events(): Flow<List<Event>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(e: Event)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun observe(o: Observation)
    @Query("SELECT * FROM observations WHERE eventId=:id ORDER BY observedAt DESC") suspend fun observations(id: String): List<Observation>
    @Query("SELECT * FROM events WHERE id=:id") suspend fun event(id: String): Event?
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC") fun tasks(): Flow<List<Task>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun create(t: Task)
    @Update suspend fun update(t: Task)
    @Query("SELECT * FROM attachments WHERE taskId=:id ORDER BY id") suspend fun attachments(id: String): List<Attachment>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun attach(a: Attachment)
    @Query("DELETE FROM events WHERE id=:id") suspend fun deleteEvent(id: String)
    @Query("DELETE FROM attachments WHERE id=:id") suspend fun deleteAttachment(id: String)
    @Query("SELECT * FROM attachments WHERE id=:id") suspend fun attachment(id: String): Attachment?
    @Transaction suspend fun saveReceipt(r: JsonNode) { validateReceipt(r); insert(Event(r["id"].asText(),r["createdAt"].asText(),r["outcome"].asText(),exportReceipt(r))) }
    suspend fun createTask(title: String, requirements: List<String>): Task {
        ensure(title.isNotBlank() && title.length <= 200 && requirements.size <= 100,"BAD_TASK")
        val t = Task(UUID.randomUUID().toString(),title,"",Json.mapper.writeValueAsString(requirements.map { mapOf("text" to it,"done" to false) }),Instant.now().toString()); create(t); return t
    }
}
@Database(entities = [Event::class,Observation::class,Task::class,Attachment::class], version = 1, exportSchema = true)
abstract class DeproofDatabase : RoomDatabase() {
    abstract fun records(): RecordsDao
    companion object { fun open(context: Context) = Room.databaseBuilder(context, DeproofDatabase::class.java,"deproof.db").build() }
}
val Context.preferences by preferencesDataStore(name = "deproof_preferences")
class Preferences(private val context: Context) {
    suspend fun rpc(cluster: String, endpoint: String) { Rpc(endpoint,cluster); context.preferences.edit { it[stringPreferencesKey("rpc_$cluster")] = endpoint } }
}
