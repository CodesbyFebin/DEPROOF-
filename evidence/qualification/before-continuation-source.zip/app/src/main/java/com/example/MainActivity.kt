package com.example

import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.core.content.FileProvider
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.edit
import com.solana.mobilewalletadapter.clientlib.ActivityResultSender
import com.example.data.*
import com.example.domain.*
import com.example.wallet.*
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import kotlinx.coroutines.*
import java.io.File
import java.time.Instant
import java.util.UUID
import java.util.Base64

class MainActivity : ComponentActivity() {
    private lateinit var wallet: Wallet
    private lateinit var db: DeproofDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wallet = Wallet(ActivityResultSender(this)); db = DeproofDatabase.open(this)
        setContent { Deproof(wallet,db.records()) }
    }
    @Composable private fun Deproof(wallet: Wallet, dao: RecordsDao) {
        val scope = rememberCoroutineScope()
        var route by remember { mutableStateOf("Now") }
        var nested by remember { mutableStateOf("Workspace") }
        var address by remember { mutableStateOf("") }
        var account by remember { mutableStateOf<String?>(null) }
        var sol by remember { mutableStateOf<Balance?>(null) }; var skr by remember { mutableStateOf<Balance?>(null) }
        var solError by remember { mutableStateOf<String?>(null) }; var skrError by remember { mutableStateOf<String?>(null) }
        var history by remember { mutableStateOf<JsonNode?>(null) }
        var historyError by remember { mutableStateOf<String?>(null) }
        var historyAddress by remember { mutableStateOf<String?>(null) }
        var busy by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }
        var work by remember { mutableStateOf<Job?>(null) }
        var review by remember { mutableStateOf<Review?>(null) }
        var reviewedFee by remember { mutableStateOf(false) }
        var memoRebuilds by remember { mutableStateOf(0) }
        var rawDraft by remember { mutableStateOf("") }
        var textExport by remember { mutableStateOf<String?>(null) }
        var fileMeta by remember { mutableStateOf<List<EvidenceFile>>(emptyList()) }
        var note by remember { mutableStateOf("") }
        var selectedTask by remember { mutableStateOf<Task?>(null) }
        var taskTitle by remember { mutableStateOf("") }
        var taskSearch by remember { mutableStateOf("") }
        var taskRequirements by remember { mutableStateOf("") }
        var receiptSearch by remember { mutableStateOf("") }
        val events by dao.events().collectAsState(initial = emptyList())
        val tasks by dao.tasks().collectAsState(initial = emptyList())
        val preferences by applicationContext.preferences.data.collectAsState(initial=emptyPreferences())
        val mainnetEndpoint=preferences[stringPreferencesKey("rpc_mainnet-beta")] ?: "https://api.mainnet-beta.solana.com"
        val devnetEndpoint=preferences[stringPreferencesKey("rpc_devnet")] ?: "https://api.devnet.solana.com"
        val mainnet=remember(mainnetEndpoint) { Rpc(mainnetEndpoint,"mainnet-beta") }
        val devnet=remember(devnetEndpoint) { Rpc(devnetEndpoint,"devnet") }
        var mainnetDraft by remember { mutableStateOf(mainnetEndpoint) }
        var devnetDraft by remember { mutableStateOf(devnetEndpoint) }
        fun run(block: suspend () -> Unit) {
            if(busy) return
            work=scope.launch { busy=true; error=null; try { block() } catch(e: CancellationException) { error="CANCELLED"; throw e } catch(e: Exception) { error=(e as? Failure)?.code ?: "OPERATION_UNAVAILABLE" } finally { busy=false } }
        }
        suspend fun importEvidence(uri: Uri, provenance: String) {
            withContext(Dispatchers.IO) {
                val id=UUID.randomUUID().toString(); val dir=File(filesDir,"evidence").apply { mkdirs() }; val target=File(dir,id)
                try {
                    contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> val buf=ByteArray(65536); var total=0L; while(true) { currentCoroutineContext().ensureActive(); val n=input.read(buf); if(n<0) break; total+=n; ensure(total<=64L*1024*1024,"FILE_TOO_LARGE"); output.write(buf,0,n) } } } ?: throw Failure("CONTENT_UNAVAILABLE")
                    val h=target.inputStream().use { sha256File(it) }; val mime=contentResolver.getType(uri) ?: "application/octet-stream"
                    val a=Attachment(id,selectedTask?.id,h.sha256,mime,h.byteLength,provenance,Instant.now().toString()); dao.attach(a)
                    withContext(Dispatchers.Main) { fileMeta=fileMeta+EvidenceFile(id,h.sha256,mime,h.byteLength,provenance) }
                } catch(e: Exception) { target.delete(); throw e }
            }
        }
        val importFile=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if(uris.isNotEmpty()) run { for(uri in uris) importEvidence(uri,"import") } }
        var cameraUri by remember { mutableStateOf<Uri?>(null) }
        val capture=rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            val uri=cameraUri; cameraUri=null
            if(ok && uri!=null) run { importEvidence(uri,"capture"); contentResolver.delete(uri,null,null) }
            else { if(uri!=null) runCatching { contentResolver.delete(uri,null,null) }; error="CAPTURE_CANCELLED_OR_UNAVAILABLE; no photo record created" }
        }
        val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            val text=textExport; if(uri!=null && text!=null) run { withContext(Dispatchers.IO) { contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: throw Failure("EXPORT_UNAVAILABLE") } }
        }
        suspend fun loadEvidence(t: Task?) {
            selectedTask=t; note=t?.note ?: ""
            fileMeta=if(t == null) emptyList() else withContext(Dispatchers.IO) { dao.attachments(t.id).map { EvidenceFile(it.id,it.digest,it.mime,it.size,it.provenance) } }
            nested="Evidence"
        }
        fun copy(text: String) {
            textExport=text
            try { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Deproof receipt",text)); error="Copied JSON" }
            catch(e: Exception) { error="CLIPBOARD_UNAVAILABLE — selectable JSON below" }
        }
        val colors=deproofColors(preferences[stringPreferencesKey("theme")] == "pearl")
        MaterialTheme(colorScheme=colors) {
            Scaffold(bottomBar={ NavigationBar { for(r in listOf("Now","Review","Receipts")) NavigationBarItem(selected=route==r,onClick={route=r},icon={ Text(r.take(1)) },label={Text(r)}) } }) { padding ->
                Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) { Image(painterResource(R.drawable.depr),"DEPR",Modifier.size(48.dp)); Column { Text("DEPROOF",style=MaterialTheme.typography.headlineSmall); Text("See, understand, verify before you sign.",style=MaterialTheme.typography.bodyMedium) } }
                    Text("Local development • device qualification not run",color=colors.onSurfaceVariant)
                    if(busy) { LinearProgressIndicator(Modifier.fillMaxWidth()); Button(onClick={work?.cancel()}) { Text("Cancel") } }
                    error?.let { Text(it,color=colors.error) }
                    when(route) {
                        "Now" -> if(nested=="Workspace") {
                            Text("Your workspace",style=MaterialTheme.typography.headlineMedium)
                            Panel("Wallet • devnet") {
                                Value("Authorized account",account ?: "Not connected. Deproof will not invent a signature.")
                                Text("Identity URI: ${BuildConfig.WALLET_IDENTITY_URI} • local development identity")
                                if(account==null) Button(enabled=!busy,onClick={run { account=wallet.connect(); review=null }}) { Text("Connect wallet") }
                                else Button(enabled=!busy,onClick={run { try { wallet.disconnect() } finally { account=null; review=null } }}) { Text("Disconnect") }
                                Text(if(wallet.strict) "Wallet advertises signed-byte return; device flow unqualified" else "Strict signing unavailable until capability is advertised")
                                Button(enabled=account!=null && wallet.strict && !busy,onClick={run {
                                    val a=account ?: throw Failure("NO_WALLET_ACCOUNT")
                                    val r=withContext(Dispatchers.IO) {
                                        val genesis=devnet.genesis(); val latest=devnet.latestDevnetBlockhash(); val bytes=buildMemo(a,latest["value"]["blockhash"].asText(),System.currentTimeMillis())
                                        val fee=devnet.estimateFee(parseTransaction(bytes).messageBytes()); devnet.simulateTransaction(bytes)
                                        Review(bytes,ReviewContext(a,"devnet",genesis,Policy.DEVNET_MEMO_V1,reviewedAt=Instant.now().toString(),lastValidBlockHeight=latest["value"]["lastValidBlockHeight"].asText(),feeLamports=fee["value"].asText(),feeSlot=fee["context"]["slot"].asText()))
                                    }
                                    review=r; reviewedFee=false; memoRebuilds=0; route="Review"
                                }}) { Text("Prepare devnet memo") }
                                Text("Mainnet SKR drafts blocked: devnet device gate and deployment qualification required. SKR staking layout unqualified.")
                            }
                            Panel("Observe a mainnet account") {
                                OutlinedTextField(address,{address=it},label={Text("Paste a Solana address")},modifier=Modifier.fillMaxWidth())
                                Button(enabled=!busy,onClick={run {
                                    val queried=address.trim(); Base58.pubkey(queried); historyAddress=queried
                                    coroutineScope {
                                        val jobs=listOf(
                                            launch { try { sol=withContext(Dispatchers.IO) { mainnet.balance(queried) }; solError=null } catch(e:Exception) { solError=(e as? Failure)?.code ?: "RPC_UNAVAILABLE" } },
                                            launch { try { skr=withContext(Dispatchers.IO) { mainnet.skrBalance(queried) }; skrError=null } catch(e:Exception) { skrError=(e as? Failure)?.code ?: "RPC_UNAVAILABLE" } },
                                            launch { try { history=withContext(Dispatchers.IO) { mainnet.history(queried) }; historyError=null } catch(e:Exception) { historyError=(e as? Failure)?.code ?: "RPC_UNAVAILABLE" } })
                                        jobs.joinAll()
                                    }
                                }}) { Text("Observe / refresh account") }
                                BalanceView("SOL",sol,solError); BalanceView("SKR (candidate official mint; live deployment validation required)",skr,skrError)
                            }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                Button(onClick={nested="Tasks"}) {Text("Tasks")}
                                Button(onClick={run { loadEvidence(null) }}) {Text("Evidence")}
                            }
                            TextButton(onClick={mainnetDraft=mainnetEndpoint;devnetDraft=devnetEndpoint;nested="Settings"}) {Text("Preferences and RPC endpoints")}
                            events.firstOrNull()?.let { Panel("Latest receipt") { Text(it.kind); Text(it.createdAt); Button(onClick={route="Receipts"}) {Text("Inspect receipt")} } }
                            Panel("Recent signatures • observed address") {
                                Value("Queried address",historyAddress ?: "None")
                                if(historyError!=null) Text("History unavailable / stale: $historyError")
                                if(history==null || history!!.isEmpty) Text("No fetched activity")
                                history?.forEach { h ->
                                    val sig=h["signature"].asText(); Value("Signature",sig)
                                    Text("${h["confirmationStatus"]?.asText() ?: "Unknown"} • slot ${h["slot"].asText()} • block time ${h["blockTime"]} • error ${h["err"]}")
                                    Button(enabled=!busy,onClick={run {
                                        val result=withContext(Dispatchers.IO) { mainnet.transaction(sig) }; val tx=parseTransaction(result.first)
                                        val r=Review(result.first,ReviewContext(tx.keys.first().address,"mainnet-beta",withContext(Dispatchers.IO){mainnet.genesis()},Policy.SKR_TRANSFER_V1,reviewedAt=Instant.now().toString(),lastValidBlockHeight=null,feeLamports=null,feeSlot=null,historical=true))
                                        val record=receipt("OBSERVED",historyAddress,"mainnet-beta","Historical transaction",r,sig) as ObjectNode
                                        val obs=record["chainObservation"] as ObjectNode; obs.put("availability","AVAILABLE"); obs.put("lastKnownStatus",if(!h["err"].isNull) "FAILED" else h["confirmationStatus"].asText("unknown").uppercase()); obs.put("slot",h["slot"].asText()); obs.set<JsonNode>("blockTime",h["blockTime"]?.let { if(it.isNull) Json.mapper.nodeFactory.nullNode() else Json.mapper.valueToTree<JsonNode>(it.asText()) }); obs.put("observedAt",Instant.now().toString()); obs.set<JsonNode>("error",h["err"])
                                        dao.saveReceipt(record); review=r; reviewedFee=false; memoRebuilds=0; route="Review"
                                    }}) {Text("Inspect historical transaction")}
                                    TextButton(onClick={startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,Uri.parse("https://explorer.solana.com/tx/$sig?cluster=mainnet-beta")))}) {Text("Open explorer")}
                                }
                            }
                        } else if(nested=="Settings") {
                            TextButton(onClick={nested="Workspace"}) {Text("Back to workspace")}
                            Text("Preferences",style=MaterialTheme.typography.headlineMedium)
                            Button(onClick={run { applicationContext.preferences.edit { it[stringPreferencesKey("theme")]=if(it[stringPreferencesKey("theme")]=="pearl") "dark" else "pearl" } }}) {Text("Switch dark / pearl theme")}
                            OutlinedTextField(mainnetDraft,{mainnetDraft=it},label={Text("Mainnet HTTPS RPC")},modifier=Modifier.fillMaxWidth())
                            OutlinedTextField(devnetDraft,{devnetDraft=it},label={Text("Devnet HTTPS RPC")},modifier=Modifier.fillMaxWidth())
                            Text("Provider URLs may contain credentials. They remain local preferences and are excluded from receipts. New endpoint selection invalidates current review.")
                            Button(enabled=!busy,onClick={run {
                                Rpc(mainnetDraft,"mainnet-beta");Rpc(devnetDraft,"devnet")
                                Preferences(applicationContext).rpc("mainnet-beta",mainnetDraft);Preferences(applicationContext).rpc("devnet",devnetDraft)
                                review=null;reviewedFee=false;solError="Stale — provider changed";skrError="Stale — provider changed";historyError="Stale — provider changed";nested="Workspace"
                            }}) {Text("Save validated endpoints")}
                        } else if(nested=="Tasks") {
                            TextButton(onClick={nested="Workspace"}) {Text("Back to workspace")}
                            Text("Tasks",style=MaterialTheme.typography.headlineMedium)
                            OutlinedTextField(taskTitle,{taskTitle=it},label={Text("Task title")})
                            OutlinedTextField(taskRequirements,{taskRequirements=it},label={Text("Requirements, one per line")})
                            Button(enabled=!busy,onClick={run { val t=dao.createTask(taskTitle,taskRequirements.lines().filter { it.isNotBlank() }); taskTitle=""; loadEvidence(t) }}) {Text("Create task")}
                            OutlinedTextField(taskSearch,{taskSearch=it},label={Text("Search tasks")})
                            if(tasks.isEmpty()) Text("No tasks yet")
                            tasks.filter { it.title.contains(taskSearch,true) }.forEach { t -> Button(onClick={run { loadEvidence(t) }}) {Text(t.title)} }
                        } else {
                            TextButton(onClick={nested="Workspace"}) {Text("Back to workspace")}
                            Text(selectedTask?.title ?: "Evidence-only workspace",style=MaterialTheme.typography.headlineSmall)
                            Text("Private files • no upload • hashes support integrity, not physical truth")
                            selectedTask?.let { t ->
                                val checklist=Json.parse(t.checklist)
                                checklist.forEachIndexed { i,item -> Row { Checkbox(item["done"].asBoolean(),onCheckedChange={ checked -> run {
                                    val revised=Json.parse(t.checklist); (revised[i] as ObjectNode).put("done",checked); val updated=t.copy(checklist=Json.mapper.writeValueAsString(revised)); dao.update(updated); selectedTask=updated
                                } }); Text(item["text"].asText(),Modifier.padding(top=12.dp)) } }
                            }
                            OutlinedTextField(note,{note=it},label={Text("Exact note")},modifier=Modifier.fillMaxWidth())
                            selectedTask?.let { t -> Button(onClick={run { val updated=t.copy(note=note); dao.update(updated); selectedTask=updated }}) {Text("Save note draft")} }
                            Button(enabled=!busy,onClick={importFile.launch(arrayOf("*/*"))}) {Text("Import files")}
                            Button(enabled=!busy,onClick={
                                val dir=File(filesDir,"evidence").apply {mkdirs()}; val file=File(dir,"capture-${UUID.randomUUID()}.jpg"); file.createNewFile()
                                val uri=FileProvider.getUriForFile(this@MainActivity,"$packageName.files",file); cameraUri=uri
                                try {capture.launch(uri)} catch(e:Exception) {cameraUri=null; file.delete(); error="NO_CAMERA_APP"}
                            }) {Text("Capture photo with system camera")}
                            Text("Video/document import supported. Location collection disabled.")
                            fileMeta.forEach { f -> Panel("${f.provenance} • ${f.mime}") {
                                Text("${f.byteLength} raw bytes"); Value("SHA-256",f.sha256)
                                Button(onClick={run { val h=withContext(Dispatchers.IO) { File(filesDir,"evidence/${f.id}").inputStream().use {sha256File(it)} }; ensure(h.sha256==f.sha256 && h.byteLength==f.byteLength,"FILE_CHANGED"); error="Raw-file integrity matches" }}) {Text("Verify file")}
                                Button(onClick={run { dao.deleteAttachment(f.id); withContext(Dispatchers.IO) { ensure(File(filesDir,"evidence/${f.id}").delete(),"FILE_DELETE_FAILED") }; fileMeta=fileMeta.filter {it.id!=f.id} }}) {Text("Delete private file")}
                            } }
                            Button(enabled=!busy,onClick={run {
                                val manifest=canonicalEvidence(fileMeta,note,selectedTask?.id,null,Instant.now().toString())
                                val r=receipt("OBSERVED",null,null,"Unsigned evidence-only manifest",taskId=selectedTask?.id,manifest=manifest); dao.saveReceipt(r); route="Receipts"
                            }}) {Text("Save unsigned manifest receipt")}
                            Button(enabled=!busy,onClick={run {
                                val manifest=canonicalEvidence(fileMeta,note,selectedTask?.id,null,Instant.now().toString())
                                val signature=withContext(Dispatchers.IO) {EvidenceSigner().signEvidenceEnvelope(manifest)}
                                dao.saveReceipt(receipt("LOCAL_EVIDENCE_SIGNED",null,null,"Evidence signed locally",taskId=selectedTask?.id,manifest=manifest,localSignature=signature)); route="Receipts"
                            }}) {Text("Sign evidence with qualified hardware key")}
                        }
                        "Review" -> {
                            val r=review
                            if(r==null) {
                                Text("No transaction selected")
                                OutlinedTextField(rawDraft,{rawDraft=it},label={Text("Import base64 transaction for read-only review")},modifier=Modifier.fillMaxWidth())
                                Button(enabled=!busy,onClick={run {
                                    val bytes=Base64.getDecoder().decode(rawDraft); val tx=parseTransaction(bytes)
                                    review=Review(bytes,ReviewContext(tx.keys.first().address,"mainnet-beta","unvalidated-import",Policy.SKR_TRANSFER_V1,reviewedAt=Instant.now().toString(),lastValidBlockHeight=null,feeLamports=null,feeSlot=null,historical=true))
                                }}) {Text("Inspect imported bytes")}
                            } else {
                                Text(if(r.context.historical) "Historical observation • read only" else "Devnet memo draft",style=MaterialTheme.typography.headlineSmall)
                                val verdicts=evaluateAllInstructions(r.tx.instructions,r.context.policy)
                                Text(if(verdicts.all {it.allowed}) "Allowed by current policy" else "Do not sign")
                                r.tx.instructions.forEachIndexed { i,ix -> Panel("Instruction ${i+1}") {
                                    Text(verdicts[i].summary); Text(verdicts[i].reason); Value("Program",ix.program)
                                    ix.accounts.forEachIndexed { j,a -> Value("Account $j • signer ${a.signer} • writable ${a.writable}",a.address) }
                                    Value("Raw instruction hex",ix.data.joinToString(""){"%02x".format(it.toInt() and 255)})
                                } }
                                Value("Account",r.context.account); Value("Cluster",r.context.cluster); Value("Genesis",r.context.genesis)
                                Value("Requester",r.context.requester); Value("Fee estimate (lamports)",r.context.feeLamports ?: "Unknown; signing blocked")
                                Value("Fee slot",r.context.feeSlot ?: "Unknown")
                                Text("Simulation is advisory. Fresh pre-handoff checks required.")
                                Value("Transaction message SHA-256",r.messageSha256); Value("Display card SHA-256",r.cardHash); Value("Review context SHA-256",r.contextHash)
                                if(!r.context.historical) {
                                    Row {Checkbox(reviewedFee,{reviewedFee=it}); Text("I reviewed the RPC fee estimate",Modifier.padding(top=12.dp))}
                                    Button(enabled=!busy && reviewedFee && account==r.context.account && wallet.strict && verdicts.all {it.allowed},onClick={run {
                                        val fresh=withContext(Dispatchers.IO) { devnet.blockhashValid(r.tx.blockhash) }
                                        if(!fresh) {
                                            ensure(memoRebuilds<1,"BLOCKHASH_EXPIRED_RETRY_EXHAUSTED")
                                            val rebuilt=withContext(Dispatchers.IO) {
                                                val latest=devnet.latestDevnetBlockhash();val bytes=buildMemo(r.context.account,latest["value"]["blockhash"].asText(),System.currentTimeMillis());val fee=devnet.estimateFee(parseTransaction(bytes).messageBytes());devnet.simulateTransaction(bytes)
                                                Review(bytes,r.context.copy(reviewedAt=Instant.now().toString(),lastValidBlockHeight=latest["value"]["lastValidBlockHeight"].asText(),feeLamports=fee["value"].asText(),feeSlot=fee["context"]["slot"].asText()))
                                            }
                                            review=rebuilt;reviewedFee=false;memoRebuilds++;throw Failure("BLOCKHASH_REBUILT_REVIEW_AGAIN")
                                        }
                                        val allowed=withContext(Dispatchers.IO) { val valid=devnet.blockhashValid(r.tx.blockhash); val liveFee=devnet.estimateFee(r.tx.messageBytes()); ensure(liveFee["value"].asText()==r.context.feeLamports,"FEE_CHANGED_REVIEW_AGAIN"); devnet.simulateTransaction(r.unsignedBytes()); canSign(r,r.unsignedBytes(),r.context,SigningGate(account,"devnet",wallet.strict,valid,reviewedFee,true,false)) }
                                        ensure(allowed,"FRESH_REVIEW_REQUIRED")
                                        val signed=wallet.sign(r); val sig=validateReturnedTransaction(r,signed,::verifyEd25519)
                                        val intent=receipt("WALLET_SIGNED",account,"devnet","Wallet signed; persisted submission intent",r,sig) as ObjectNode
                                        (intent["submission"] as ObjectNode).put("state","SUBMITTING").put("attemptedAt",Instant.now().toString())
                                        dao.saveReceipt(intent) // Durable identity before RPC send. Never auto-retry.
                                        try {
                                            withContext(Dispatchers.IO) {devnet.submitSignedTransaction(signed,sig)}
                                            dao.observe(Observation(UUID.randomUUID().toString(),intent["id"].asText(),Instant.now().toString(),Json.mapper.writeValueAsString(Json.obj("submissionState" to "SUBMITTED","broadcast" to true,"submittedByDeproof" to true,"rpcAcceptedAt" to Instant.now().toString(),"signature" to sig))))
                                            error="RPC accepted exact signed bytes. Confirmation has not been claimed."
                                        } catch(e: Exception) {
                                            dao.observe(Observation(UUID.randomUUID().toString(),intent["id"].asText(),Instant.now().toString(),Json.mapper.writeValueAsString(Json.obj("submissionState" to "SUBMISSION_UNKNOWN","broadcast" to null,"submittedByDeproof" to null,"signature" to sig))))
                                            error="SUBMISSION_UNKNOWN — inspect the known signature; do not resubmit blindly"
                                        }
                                        review=null; reviewedFee=false; route="Receipts"
                                    }}) {Text("Approve in wallet")}
                                    Text("Your wallet requests authorization. Deproof validates signed bytes before submitting. No automatic mainnet spending.")
                                }
                                Button(enabled=!busy,onClick={run { dao.saveReceipt(receipt("REJECTED",r.context.account,r.context.cluster,"Rejected locally. Nothing submitted.",r)); review=null; reviewedFee=false; route="Receipts" }}) {Text("Reject locally")}
                                TextButton(onClick={review=null; reviewedFee=false}) {Text("Clear review")}
                            }
                        }
                        "Receipts" -> {
                            Text("Receipts",style=MaterialTheme.typography.headlineMedium)
                            OutlinedTextField(receiptSearch,{receiptSearch=it},label={Text("Search real receipts")})
                            if(events.isEmpty()) Text("No receipts yet. Observe, reject or save evidence to create a record.")
                            events.filter { it.payload.contains(receiptSearch,true) }.forEach { e -> Panel(statusLabel(e.kind)) {
                                val record=Json.parse(e.payload)
                                Text(record["summary"].asText()); Text(e.createdAt)
                                Text("Original event provenance: ${record["submission"]}")
                                var obs by remember(e.id) {mutableStateOf<List<Observation>>(emptyList())}
                                LaunchedEffect(e.id,events) {obs=dao.observations(e.id)}
                                obs.forEach { Text("Append-only observation ${it.observedAt}: ${it.payload}") }
                                val sig=record["signature"].takeUnless {it.isNull}?.asText()
                                if(sig!=null) Button(enabled=!busy,onClick={run {
                                    val rpc=if(record["network"].asText()=="devnet") devnet else mainnet
                                    val observed=try { withContext(Dispatchers.IO) { rpc.observeSettlement(sig) }.let { Json.obj("availability" to "AVAILABLE","status" to if(it.isNull) "UNKNOWN" else if(!it["err"].isNull) "FAILED" else it["confirmationStatus"].asText("unknown").uppercase(),"raw" to it) } } catch(ex:Exception) {Json.obj("availability" to "UNAVAILABLE","status" to null,"error" to ((ex as? Failure)?.code ?: "RPC_UNAVAILABLE"))}
                                    dao.observe(Observation(UUID.randomUUID().toString(),e.id,Instant.now().toString(),Json.mapper.writeValueAsString(observed))); obs=dao.observations(e.id)
                                }}) {Text("Observe known signature")}
                                Button(onClick={copy(e.payload)}) {Text("Copy original event JSON")}
                                Button(onClick={textExport=e.payload; export.launch("deproof-${e.id}.json")}) {Text("Export original event")}
                                Button(onClick={run { val observations=dao.observations(e.id); val bundle=Json.obj("schema" to "deproof-portable-event-v1","event" to record,"observations" to observations.map { Json.obj("id" to it.id,"observedAt" to it.observedAt,"payload" to Json.parse(it.payload)) }); textExport=Json.mapper.writerWithDefaultPrettyPrinter().writeValueAsString(bundle); export.launch("deproof-bundle-${e.id}.json") }}) {Text("Export event and observations")}
                                Button(enabled=!busy,onClick={run {dao.deleteEvent(e.id)}}) {Text("Delete local receipt")}
                            } }
                            textExport?.let { SelectionContainer { Text(it,fontFamily=FontFamily.Monospace) } }
                        }
                    }
                    Text("Built by CodesbyFebin",color=colors.onSurfaceVariant)
                }
            }
        }
    }
}
@Composable private fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {Text(title,style=MaterialTheme.typography.titleMedium); content()} } }
@Composable private fun Value(label: String, value: String) { Column {Text(label,style=MaterialTheme.typography.labelLarge); SelectionContainer {Text(value,fontFamily=FontFamily.Monospace)} } }
@Composable private fun BalanceView(label: String, balance: Balance?, error: String?) { Text(label,style=MaterialTheme.typography.titleMedium); if(balance!=null) {Value("Observed address",balance.address); Text("${balance.value} • slot ${balance.slot} • ${balance.observedAt}")}; if(error!=null) Text("${if(balance!=null) "Stale — last successful read shown" else "Unavailable"}: $error"); if(balance==null && error==null) Text("Not queried") }
