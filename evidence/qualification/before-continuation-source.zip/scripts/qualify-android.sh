#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./gradlew --no-daemon assembleDebug testDebugUnitTest lintDebug
APK=app/build/outputs/apk/debug/app-debug.apk
test -s "$APK"
shasum -a 256 "$APK"
