# Local qualification report

Deproof / DEPR — Built by CodesbyFebin. Full requested scope remains incomplete. BUILD_QUALIFIED, CORE_DEVICE_QUALIFIED and FULL_SCOPE_QUALIFIED are all false. No real wallet memo, hardware signature, live contribution, external payout is claimed.

## Implemented local components

- Native Kotlin/Compose source: Now/Review/Receipts, MWA signed-byte adapter, RPC reads, strict legacy/v0-without-lookups parsing, immutable complete-message/context binding, Room events/observations/tasks/attachments, raw-file import/hashing and Keystore source. Android assembly, JVM tests and lint passed; device qualification remains unrun.
- Dependency-free Go node agent and macOS binary: persistent software identity, expiring scoped signed pairing/commands, revocation/replay library, loopback TLS source, consent defaults, durable quota reservation, actual fixed-endpoint HTTP flow source and signed local metering. Network/runtime gates unrun.
- Independent Python P-256/Ed25519/file verifier, exact-byte portable bundles and AES-256-GCM owner-key backups, constrained JCS schemas and Kotlin/Python golden vectors. Missing files/chain/physical truth are reported separately.
- Pinned gnark cubic proof producer and separate verifier source. Local proof generated and independently verified; wrong public input rejected. Educational setup only.
- Seven local website pages with status/search/JSON inspection, setup/security/privacy/license documentation and exact registry coverage. Static checks pass when recorded below; browser interaction/accessibility checks unrun.

## Exact executed commands

| Gate | Command | Exit | Result | Evidence |
| --- | --- | --- | --- | --- |
| core-tests | `python3 scripts/qualify-core.py` | 0 | PASS | [evidence/qualification/core-tests.log](../evidence/qualification/core-tests.log) |
| node-tests | `scripts/qualify-node.sh` | 0 | PASS | [evidence/qualification/node-tests.log](../evidence/qualification/node-tests.log) |
| verifier-tests | `python3 -m unittest discover -s tools -p test_*.py` | 0 | PASS | [evidence/qualification/verifier-tests.log](../evidence/qualification/verifier-tests.log) |
| android-build | `scripts/qualify-android.sh` | 0 | PASS | [evidence/qualification/android-build.log](../evidence/qualification/android-build.log) |
| prover-tests | `scripts/qualify-prover.sh` | 0 | PASS | [evidence/qualification/prover-tests.log](../evidence/qualification/prover-tests.log) |
| registry-checks | `python3 scripts/check-registries.py` | 0 | PASS | [evidence/qualification/registry-checks.log](../evidence/qualification/registry-checks.log) |
| web-build | `python3 scripts/build-web.py` | 0 | PASS | [evidence/qualification/web-build.log](../evidence/qualification/web-build.log) |
| web-checks | `python3 scripts/qualify-web.py` | 0 | PASS | [evidence/qualification/web-checks.log](../evidence/qualification/web-checks.log) |

All nonzero exits remain failures. Infrastructure classification is BLOCKED where the recorded error identifies unavailable prerequisites. Passing local unit checks do not imply device/external qualification.

## Exact counts

- features: {"BLOCKED": 19, "IMPLEMENTED_UNVERIFIED": 86, "NOT_STARTED": 8, "VERIFIED": 7}
- core-checks: {"NOT_RUN": 81, "PASS": 19}
- functions: {"BLOCKED": 14, "IMPLEMENTED_UNVERIFIED": 51, "NOT_STARTED": 2, "VERIFIED": 19}
- ecosystem-requirements: {"BLOCKED": 12, "IMPLEMENTED_UNVERIFIED": 18}

Counts remain 120 F, 100 C, 62 FN + 24 EF = 86 contracts and 30 E. Overlaps are not added as new unique features. Per-entry evidence is in implementation-status.json and root registries.

## Blocked, failed and unrun gates

- **DEVICE_WALLET_HARDWARE: NOT_RUN** — Approved adb devices -l completed successfully and listed no connected devices; wallet/hardware tests remain unrun. Recovery: adb devices -l; install actual built APK and follow docs/setup.md.
- **LIVE_RPC: NOT_RUN** — Approved dependency access works, but no attributable app wallet/balance/mint/chain observation has been recorded. Recovery: Restore HTTPS RPC access, collect attributable cluster/slot/time evidence.
- **HOST_RUNTIME: BLOCKED** — Docker socket denied; Linux rootless/isolation and hostile fixtures not run. Hosting remains disabled. Recovery: Qualify user-owned Linux container runtime/resource/network/filesystem limits and pinned profile.
- **NODE_NETWORK: NOT_RUN** — Live TLS pairing/actual transfer/stop/peer counters not exercised; policy tests use local library/HTTP handlers, not a real network topology.
- **P5_EXTERNAL_ADAPTERS: BLOCKED** — SKR staking layouts, additional provider interfaces/authorization and external job/payout/network membership are unqualified.
- **SOURCE_COMPLETENESS: NOT_RUN** — General lookup resolution, mainnet draft gate, legacy migration, crash reconciliation, previews/capture recovery, app node wiring, live owner revocation, complete adaptive/localized UI and device-qualified settings/themes and Android encrypted-backup integration remain incomplete.
- **RELEASE_AND_RIGHTS: BLOCKED** — No release signing, installed-device qualification, full resolved SBOM/advisory review or imported-asset rights clearance. Local work only.
- **PROOF_PRODUCTION_SETUP: NOT_RUN** — Local cubic Groth16 demo passed valid and wrong-public-input checks. Trusted setup, job authentication, execution isolation and external provider qualification remain unrun.

## Produced artifacts

- `node-agent/build/deproof-node` — darwin-amd64-node-binary; SHA-256 `35e59a06d9a943be2a11fd74b3866d7d9932eea60a713ff857c9ee5c159ae460`
- `gradle/wrapper/gradle-wrapper.jar` — official-gradle-wrapper-jar; SHA-256 `b3a875ddc1f044746e1b1a55f645584505f4a10438c1afea9f15e92a7c42ec13`
- `tools/verify.py` — independent-verifier; SHA-256 `65454c735b3ebcc7d1ee07a91de233486a03703d940d8b6ee1a43df2aa4eb613`
- `app/build/outputs/apk/debug/app-debug.apk` — debug-apk; SHA-256 `162c3c8e2076b1f70ac8d8e64482312de80fc83c1588b51239073faeeabcff81`
- `prover-worker/build/qualified-result-20261006T050420Z-60151/circuit.r1cs` — local-proof-artifact; SHA-256 `d66951a99a8361b0677e6e08a8075773c1622f33645b2b1182ee60db39ef8954`
- `prover-worker/build/qualified-result-20261006T050420Z-60151/verification-key.bin` — local-proof-artifact; SHA-256 `1e70273cda7799bf7650ca33ab5f719081d076dc8dd62ea7a657d947df2e5dd7`
- `prover-worker/build/qualified-result-20261006T050420Z-60151/public-witness.bin` — local-proof-artifact; SHA-256 `da07f711885f5cdbf5a86f5e0c2d503f1cf6cf1ffe71d86cff6a4566b8c833cd`
- `prover-worker/build/qualified-result-20261006T050420Z-60151/manifest.json` — local-proof-artifact; SHA-256 `39648eff367b6c022088a7050f2ab3b4ec689438618b6f5342b9bc299bc48ebb`
- `prover-worker/build/qualified-result-20261006T050420Z-60151/proof.bin` — local-proof-artifact; SHA-256 `547ab90e2af8648705ca95ecbaba433d28ce13165bdaca1cdfd4dced8a1ea78c`
- `prover-worker/build/prove` — local-proof-prove; SHA-256 `23e498e0729cb042528d564fe3e489c6460322d09ad3853e2506508f4f6f61cf`
- `prover-worker/build/verify` — local-proof-verify; SHA-256 `f7c6c016fcf0c09919d61e2dffa75e4bed8f0ab11d14145c087281552b7c3301`

APK expected after a successful build: `app/build/outputs/apk/debug/app-debug.apk` (produced; checksum above). Prover artifacts expected under `prover-worker/build/` (local producer/verifier and proof artifacts produced; external qualification unrun). Node binary is macOS x86_64 only; not an isolated Linux-host qualification.

See artifact-checksums.txt for source/tool/schema/fixture/evidence checksums. Source snapshot: `evidence/qualification/deproof-source-snapshot.zip`, produced locally with caches, secrets, user configuration and imported assets preserved locally; public redistribution rights unresolved; its external checksum is authoritative. No push, release, deployment, token issuance or mainnet spending performed.
