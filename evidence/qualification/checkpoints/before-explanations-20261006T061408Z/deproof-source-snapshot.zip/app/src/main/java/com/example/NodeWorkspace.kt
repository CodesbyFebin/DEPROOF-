package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.*
import com.example.domain.*
import com.fasterxml.jackson.databind.JsonNode
import kotlinx.coroutines.*
import java.time.Instant

@Composable fun NodeWorkspace(dao: RecordsDao, page: String) {
    val repository=remember {NodeRepository(dao)};val scope=rememberCoroutineScope()
    val sessions by dao.nodeSessions().collectAsState(emptyList())
    var selected by remember {mutableStateOf<String?>(null)}
    val session=sessions.firstOrNull {it.id==selected} ?: sessions.lastOrNull()
    var endpoint by remember {mutableStateOf("https://127.0.0.1:9843")}
    var pin by remember {mutableStateOf("")};var fingerprint by remember {mutableStateOf("")}
    var challenge by remember {mutableStateOf("")};var code by remember {mutableStateOf("")}
    var scopes by remember {mutableStateOf(setOf("READ_NODE"))}
    var confirmed by remember {mutableStateOf(false)}
    var status by remember(session?.id) {mutableStateOf<JsonNode?>(null)}
    var error by remember {mutableStateOf<String?>(null)}
    var working by remember {mutableStateOf(false)}
    var contributionEndpoint by remember {mutableStateOf("")};var cap by remember {mutableStateOf("1048576")}
    var rate by remember {mutableStateOf("65536")};var bytes by remember {mutableStateOf("4096")}
    var sharingConsent by remember {mutableStateOf(false)};var inputConsent by remember {mutableStateOf(false)}
    var jobs by remember {mutableStateOf<JsonNode?>(null)}
    fun command(action: String,params: JsonNode=Json.obj()) {
        val peer=session ?: return
        scope.launch {
            val exclusive=action !in setOf("stop","cancelProof","revoke","observe")
            if(exclusive && working) return@launch
            if(exclusive) working=true
            error=null
            try {
                val result=repository.command(peer,action,params)
                if(action=="observe") status=result
                else if(action=="discoverProofJobs") jobs=result
                else if(action=="revoke") {status=null;error="Session revoked by node; further commands denied"}
                else {error="Node returned an authenticated result. Refresh status for current runtime state."}
            } catch(e: Exception) {error=(e as? Failure)?.code ?: "NODE_UNAVAILABLE — status unknown; refresh, do not replay"}
            finally {if(exclusive) working=false}
        }
    }
    Text(page,style=MaterialTheme.typography.headlineMedium)
    Text("User-owned node • loopback TLS • no wallet keys • Built by CodesbyFebin")
    if(page=="Nodes") {
        Text("Pair through an explicitly configured local port forward. Approve both identities from the node owner's terminal.")
        OutlinedTextField(endpoint,{endpoint=it;confirmed=false},label={Text("Loopback HTTPS endpoint")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(pin,{pin=it.trim();confirmed=false},label={Text("TLS certificate SHA-256")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(fingerprint,{fingerprint=it.trim();confirmed=false},label={Text("Node Ed25519 fingerprint")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(challenge,{challenge=it;confirmed=false},label={Text("Owner's pairing challenge JSON")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(code,{code=it.trim()},label={Text("Single-use pairing code")},modifier=Modifier.fillMaxWidth())
        NodeProtocol.SCOPES.forEach {s -> Row {Checkbox(s in scopes,{checked -> scopes=if(checked) scopes+s else scopes-s;confirmed=false});Text(s,Modifier.padding(top=12.dp))}}
        Row {Checkbox(confirmed,{confirmed=it});Text("I checked the host and TLS fingerprints and approve these scopes",Modifier.padding(top=12.dp))}
        Button(enabled=confirmed && !working,onClick={scope.launch {working=true;error=null;try {repository.pair(endpoint,pin,Json.parse(challenge),code,fingerprint,scopes.sorted());code="";confirmed=false;error="Paired; refresh to observe the node"} catch(e:Exception){error=(e as? Failure)?.code ?: "PAIRING_UNAVAILABLE"}finally{working=false}}}) {Text("Pair authenticated node")}
    }
    sessions.forEach {s -> TextButton(onClick={selected=s.id;status=null;jobs=null}) {Text("${s.fingerprint.take(12)} • ${s.state}")} }
    session?.let {peer ->
        Text("Approved fingerprint: ${peer.fingerprint}")
        Text("Session: ${peer.state} • scopes ${peer.scopes}")
        Button(enabled=peer.state=="PAIRED",onClick={command("observe")}) {Text("Refresh observed node status")}
        Button(enabled=peer.state=="PAIRED",onClick={command("revoke")}) {Text("Revoke this session and stop its flows")}
        status?.let {s -> SelectionContainer {Text(Json.mapper.writerWithDefaultPrettyPrinter().writeValueAsString(s))};Text("Observed at ${s["observedAt"]}. This snapshot becomes stale; refresh after every action.")}
        if(page=="Nodes") {
            Text("Inspect the displayed immutable service profile before explicitly requesting start. Only the qualified local network-isolated profile is supported; unavailable runtimes refuse execution.")
            Button(enabled=!working,onClick={command("startService",Json.obj("profileDigest" to status?.get("hosting")?.get("profileDigest")?.asText(),"explicitConsent" to true))}) {Text("Request allowlisted service start")}
            Button(onClick={command("stopService")}) {Text("Request service stop")}
        }
        if(page=="Bandwidth") {
            Text("Default off. Only an owner-allowlisted known-byte receiver is supported. No proxy, rewards or provider membership implied.")
            OutlinedTextField(contributionEndpoint,{contributionEndpoint=it;sharingConsent=false},label={Text("Owner-allowlisted HTTPS receiver")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(cap,{cap=it;sharingConsent=false},label={Text("Total reserved byte cap (including previous use)")})
            OutlinedTextField(rate,{rate=it;sharingConsent=false},label={Text("Bytes per second (maximum 1048576)")})
            Row {Checkbox(sharingConsent,{sharingConsent=it});Text("I permit this receiver to receive known-byte test traffic for 10 minutes. Local counters do not establish rewards.",Modifier.padding(top=12.dp))}
            Button(enabled=sharingConsent && !working,onClick={command("consent",Json.obj("endpoint" to contributionEndpoint,"capBytes" to cap,"bytesPerSecond" to rate,"deadline" to Instant.now().plusSeconds(600).toString(),"explicitConsent" to true));sharingConsent=false}) {Text("Set explicit bounded consent")}
            OutlinedTextField(bytes,{bytes=it},label={Text("Payload bytes to contribute (maximum 1048576)")})
            Button(enabled=!working,onClick={command("transfer",Json.obj("bytes" to bytes))}) {Text("Start constrained transfer")}
            Button(onClick={command("stop")}) {Text("Stop flow and disable consent")}
            Text("Stop acknowledgment is a request. Refresh until activeOperations is empty; signed results are in Receipts.")
        }
        if(page=="Proof jobs") {
            Button(enabled=!working,onClick={command("discoverProofJobs")}) {Text("Discover owner-pinned local job")}
            jobs?.let {j -> SelectionContainer {Text(Json.mapper.writerWithDefaultPrettyPrinter().writeValueAsString(j))}}
            Text("Supported local educational cubic circuit only. No private evidence/witness is uploaded. Trusted setup and external provider acceptance remain unqualified.")
            Row {Checkbox(inputConsent,{inputConsent=it});Text("I approve execution of the displayed job on the paired host using its public local sample input",Modifier.padding(top=12.dp))}
            Button(enabled=jobs?.get("jobId")!=null && inputConsent && !working,onClick={command("proof",Json.obj("jobId" to jobs!!["jobId"].asText(),"explicitConsent" to true));inputConsent=false}) {Text("Execute and independently verify job")}
            Button(onClick={command("cancelProof")}) {Text("Cancel active proof job")}
        }
    } ?: Text("No paired node. Open Nodes to pair.")
    if(working) Text("Awaiting actual node result… stop/revoke remain available")
    error?.let {Text(it)}
}
